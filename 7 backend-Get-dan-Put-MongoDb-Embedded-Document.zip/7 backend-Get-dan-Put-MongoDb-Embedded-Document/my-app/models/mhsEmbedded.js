const mongoose = require('mongoose')

const mhsEmbeddedSchema = new mongoose.Schema({
    nim:{
        required: true,
        type: String
    },
    nama:{
        required: true,
        type: String
    },
    angkatan:{
        required: true,
        type: String
    },
    prodi:{
        required: true,
        type: String
    },
    nilai :[{
        kdmk : String,
        matakuliah : String,
        dosen: String,
        semester: Number,
        nilai: String,
    }]
})

const Mahasiswa = mongoose.model('Mahasiswa', mhsEmbeddedSchema);
module.exports = Mahasiswa;