const express = require('express'); 
const routerNilai = express.Router();
const ctrNilai = require("../controllers/mhsEmbedded");

// Nilai
routerNilai.get('/mahasiswa/nilai/', ctrNilai.findNilai);
routerNilai.get('/mahasiswa/nilai/:nim', ctrNilai.findNilaiByNim);
routerNilai.put('/mahasiswa/nilai/:nim', ctrNilai.insertNilai);


module.exports = routerNilai