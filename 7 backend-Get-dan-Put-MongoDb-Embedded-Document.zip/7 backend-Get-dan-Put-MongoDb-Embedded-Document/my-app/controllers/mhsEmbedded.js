const Mahasiswa = require('../models/mhsEmbedded.js'); 

module.exports = {

    insertNilai: async (req, res) => {

        const filter = {nim : req.params.nim };
        const updatedNilai ={
            $push: {
                nilai: {
                    kdmk: req.body.kdmk,
                    matakuliah: req.body.matakuliah,
                    dosen: req.body.dosen,
                    semester: req.body.semester,
                    nilai: req.body.nilai,
                }
            }            
        };

        try {
            await Mahasiswa.updateOne(filter, updatedNilai);
            res.status(200).json(updatedNilai);
        } catch (error) {
            res.status(400).json({message: error.message});
        };

    },

    findNilai: async (req, res) => {

        try {
            const data = await Mahasiswa.find();
            res.status(200).json(data);
        } catch (error) {
            res.status(400).json({ message: error.message});
        }

    },


    findNilaiByNim: async (req, res) => {

        const nim = req.params.nim;
        try {
            const data = await Mahasiswa.findOne({"nim" : nim},{"_id":0,"nilai" : 1});
            res.status(200).json(data);
        } catch (error) {
            res.status(400).json({ message: error.message});
        }

    },

}