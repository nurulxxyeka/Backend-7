const express = require('express');
const mongoose = require('mongoose');
const app = express();
const port = 5000;


app.use(express.json());
app.use(express.urlencoded({ extended: true }));


// NILAI
const routerNilai = require('./routers/mhsEmbedded');
app.use(routerNilai);


// KONEKSI MONGODB
require('dotenv').config();
mongoose.connect(process.env.DATABASE_URL)
.then(()=> {
    console.log('Connected to database!');
})
.catch (() => {
    console.log('Connected failed!');
});


app.listen(port,() => {
    console.log('Server runing at port', port);
});